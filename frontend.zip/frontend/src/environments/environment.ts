// src/environments/environment.ts
export const environment = {
  production: false,
  recaptchaSiteKey: '6LfLwAYrAAAAAOQP5tBqg3hYVjU5mqAm85gSKMGk',
  emailjs: {
    serviceId: 'service_l0dmrhh',
    templateId: 'template_ighkrbg',
    userId: '7PtPsVHklGkD5VUij',
  },
};
