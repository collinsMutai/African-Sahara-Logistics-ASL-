import { Component } from '@angular/core';

@Component({
  selector: 'app-sectors',
  standalone: true,
  imports: [],
  templateUrl: './sectors.component.html',
  styleUrl: './sectors.component.css'
})
export class SectorsComponent {

}
